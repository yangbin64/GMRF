#!/bin/sh
year=2018
month=04
days=30

path=../nk-stock-prediction/preprocessed/seg3/${year}/${month}

for day in `seq -f %02g 1 1 $days`
do
    zcat ${path}/${year}${month}${day}.csv.gz | grep -e 60832 -e 60831 | grep -e 60892 -e 60893  -e 60894 -e 60895 -e 60896 -e 60897 | grep -e 208050 -e 208052 -e 208053 -e 208056 -e 208057 -e 60944 > ${year}/${month}/${year}${month}${day}.csv
done

