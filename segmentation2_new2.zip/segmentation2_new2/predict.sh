#!/bin/sh

python predict.py training.csv testing.csv weekday.csv

