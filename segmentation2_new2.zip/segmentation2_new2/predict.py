import numpy as np
import pandas as pd
import sys
import math

def train(filename_training, filename_testing, filename_weekday):
    df_weekday = pd.read_csv(filename_weekday, sep=",", header=0, index_col=False, dtype=np.str)
    df_weekday = df_weekday.loc[:,['date', 'weekday1']]
    print(df_weekday)

    df_training = pd.read_csv(filename_training, sep=",", header=0, index_col=False, dtype={'date':np.str, 'menu':np.str, 'attr1':np.str, 'attr2':np.str,'attr3':np.str, 'imp':np.int32}).merge(df_weekday, on='date', how='left')
    print(df_training)

    df_groupby = df_training.groupby(['menu', 'attr1', 'attr2', 'attr3', 'weekday1']).mean()
    df_predictor = df_groupby.reset_index().rename(columns={'imp': 'imp_pred'})
    print(df_predictor)

    df_testing = pd.read_csv(filename_testing, sep=",", header=0, index_col=False, dtype={'date':np.str, 'menu':np.str, 'attr1':np.str, 'attr2':np.str,'attr3':np.str, 'imp':np.int32}).merge(df_weekday, on='date', how='left')
    print(df_testing)

    df_prediction = pd.merge(df_testing, df_predictor, how='left')
    print(df_prediction)

    df_prediction['AE'] = abs(df_prediction['imp_pred']-df_prediction['imp'])
    df_prediction['SE'] = df_prediction['AE']*df_prediction['AE']
    df_prediction['ALE'] = abs(np.log(df_prediction['imp_pred']+1)-np.log(df_prediction['imp']+1))
    print(df_prediction)

    print(df_prediction['imp'].mean())
    print(df_prediction['imp_pred'].mean())

    print()
    print('MAE:  ' + str(df_prediction['AE'].mean()))
    print('RMSE: ' + str(np.sqrt(df_prediction['SE'].mean())))
    print('MALE: ' + str(df_prediction['ALE'].mean()))

def main():
    filename_training = sys.argv[1]
    filename_testing = sys.argv[2]
    filename_weekday = sys.argv[3]
    train(filename_training, filename_testing, filename_weekday)

main()

