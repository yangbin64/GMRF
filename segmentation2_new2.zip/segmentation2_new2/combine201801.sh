#!/bin/sh
year=2018
month=01
days=31

echo 'date,menu,attr1,attr2,attr3,imp' > ${year}${month}.csv

for day in `seq -f %02g 1 1 $days`
do
    awk -f combine.awk -F , -v yearmonthday="${year}${month}${day}" ${year}/${month}/${year}${month}${day}.csv >> ${year}${month}.csv
    #zcat ${path}/${year}${month}${day}.csv.gz | grep -e 60832 -e 60831 | grep -e 60892 -e 60893  -e 60894 -e 60895 -e 60896 -e 60897 | grep -e 208050 -e 208052 -e 208053 -e 208056 -e 208057 -e 60944 > ${year}/${month}/${year}${month}${day}.csv
done

